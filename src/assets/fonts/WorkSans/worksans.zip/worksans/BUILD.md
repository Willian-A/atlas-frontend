## Static Font Build ##

- Export "OTF" option (OTF and TTF will be generated) in Glyphs App Version 2.5.2 (1179)
	- Remove Overlap
	- Autohint

## Variable Font Build ##

- Run build.sh (`sh build.sh` in Terminal)

## Dependancies ##
- fontmake